require 'test_helper'

class JobsJsonTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
