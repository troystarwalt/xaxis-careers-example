class JobsJson < ActiveRecord::Base
end
